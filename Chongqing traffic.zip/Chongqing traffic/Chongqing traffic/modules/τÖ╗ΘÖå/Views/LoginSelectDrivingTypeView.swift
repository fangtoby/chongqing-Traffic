//
//  LoginSelectDrivingTypeView.swift
//  Chongqing traffic
//
//  Created by Zhu Xingle on 2018/11/13.
//  Copyright © 2018 Beijing Guo Jiao Yun Net Technology Co., Ltd. All rights reserved.
//

import UIKit

class LoginSelectDrivingTypeView: UIView {
    
    lazy var bgView: UIView = {
        let bgView = UIView()
        
        return bgView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        //        fatalError("init(coder:) has not been implemented")
    }
}
